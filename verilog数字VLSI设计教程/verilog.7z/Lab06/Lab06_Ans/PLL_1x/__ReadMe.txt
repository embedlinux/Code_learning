2007-04-16 jmw:  This PLL is a special implementation which is
     meant to show how a digital model can be used for more accurate
     lock-in when applied in 1 1x configuration.
     This configuration might be used to model the clock-latency
     cancellation device described briefly in the Workbook text
     for Week 2, Class 2.
