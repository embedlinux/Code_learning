2006-10-11 jmw:  The macroes are initially defined
           in a way which COULD occur if two different
           designers were working at the top level and
           at the second level down (Level2.v).

           Compilation in the HierDefineBAD.vcs order
           causes VCS to issue an error message and quit;
           QuestaSim issues warnings but permits the
           design to be compiled.
