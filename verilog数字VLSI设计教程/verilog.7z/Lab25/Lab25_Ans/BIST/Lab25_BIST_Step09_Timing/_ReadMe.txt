The timing constraints make a netlist 
which simulates correctly.

