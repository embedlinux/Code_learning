#ifndef _GRAMMARMATCH_H_ 
#define _GRAMMARMATCH_H_


int IsLeft(char c);

int IsRight(char c);

int IsMatch(char left,char right);

int scanner(const char* code);

#endif
